<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <title>Error</title>
    <link rel='stylesheet' href='style.css'>
</head>
<body>
    <div class='container'>
        <h2>Error</h2>
        <div class='alert alert-danger'>
            <p>Sorry, you've made an invalid request. Please <a href='index.php' class='alert-link'>go back</a> and try again.</p>
        </div>
    </div>
</body>
</html>
