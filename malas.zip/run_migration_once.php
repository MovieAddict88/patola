<?php
require_once 'migrations/20240801_create_troubleshooting_guides_table.php';
