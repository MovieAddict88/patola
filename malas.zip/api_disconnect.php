<?php
// This file is deprecated. All data usage reporting is now handled by api_check_status.php.
