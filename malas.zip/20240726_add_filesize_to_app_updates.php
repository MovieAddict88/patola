<?php
$sql = 'ALTER TABLE app_updates ADD COLUMN file_size BIGINT;';
?>